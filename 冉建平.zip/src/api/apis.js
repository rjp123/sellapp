import axios from 'axios'
let req = axios.create({
  baseURL: 'http://127.0.0.1:3000',
  timeout: 10000
})
export function getSellers () {
  return req.get('/api/seller')
}
export function getGoods(){
  return req.get('/api/goods');
}
