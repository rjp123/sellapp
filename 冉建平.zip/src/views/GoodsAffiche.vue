<template>
  <div>
      <h1>商品公告</h1>
  </div>
</template>

<script>
export default {}
</script>

<style lang="scss" scoped>
</style>
