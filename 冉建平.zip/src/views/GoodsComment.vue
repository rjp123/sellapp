<template>
    <div>
  <h1>商品评论</h1>
    </div>
</template>

<script>
export default {

}
</script>

<style lang="less" scoped>

</style>
