<template>
    <div>
      <div> <h1>商家页面</h1> </div>
    </div>
</template>

<script>
export default {

}
</script>

<style lang="scss" scoped>

</style>
